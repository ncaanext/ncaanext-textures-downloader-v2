.
NOTE: This is for first-time installation only. For incremental texture updates, 
use the Textures Downloader utility: http://textures.ncaanext.com

INSTRUCTIONS:

1. Extract the "download_textures.bat" file and the "mingit" folder into 
   your PCSX2 textures directory (Eg. C:\\PCSX2\textures)

2. Double-click "download_textures.bat" to begin the installation.

3. After successful installation, you can delete "download_textures.bat" and "mingit".

Done!

For future updates, use the Textures Downloader utility: http://textures.ncaanext.com

ATTENTION:
Textures are only half of the installation process. Be sure to create your modded ISO
and follow the emulator setup instructions per the guides at https://ncaanext.com